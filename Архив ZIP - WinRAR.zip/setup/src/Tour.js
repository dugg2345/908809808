import React, { useState } from 'react';

const Tour = () => {
  return <h2>tour component</h2>;
};

export default Tour;
